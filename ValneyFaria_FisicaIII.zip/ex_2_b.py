# !/usr/bin/python3
# coding: UTF-8

"""
	Um elétron é projetado com uma velocidade inicial Vi = 3 * 10^6 m/s na direção x na região entre duas placas carregadas com cargas opostas. Quando o elétron deixa a região entre as placas, ele sofreu uma deflexão vertical de 2cm. Suponha que o campo elétrico entre as placas e que o campo elétrico fora da região das placas seja nulo.

	a) Qual a intensidade do campo elétrico entre as placas?
	b) Em qual ponto Yf sobre a tela localizada a 1m de distância das placas o elétron irá colidir?
"""

